#ifndef UNTITLED_POSITION_H
#define UNTITLED_POSITION_H

enum Position {
    Director = 100,
    Manager = 75,
    OfficeWorker = 50,
    Consultant = 25,
    Unemployed = 0
};

   /*static const Position AllPos[] = { Director, Manager, OfficeWorker,
                                       Consultant,  Unemployed};*/
#endif //UNTITLED_POSITION_H
