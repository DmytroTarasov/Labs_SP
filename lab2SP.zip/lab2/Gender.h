#ifndef UNTITLED_GENDER_H
#define UNTITLED_GENDER_H

enum Gender {
    Male,
    Female,
    Else
};

    /*static const Gender AllGen[] = { Male, Female, Else};*/

#endif //UNTITLED_GENDER_H
